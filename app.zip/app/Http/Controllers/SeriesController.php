<?php

namespace App\Http\Controllers;

use App\Models\Series;
use App\Models\Wallpaper;
use Illuminate\Http\Request;

class SeriesController extends Controller
{
    public function index(Request $request)
    {
        $query = trim((string) $request->input('q', ''));

        $series = Series::query()
            ->published()
            ->allowedRating()
            ->when($query !== '', fn ($q) => $q->search($query)) // Memanggil scope yang sangat ringan
            ->latest()
            ->paginate(32)
            ->appends(['q' => $query]);

        return view('series.index', compact('series', 'query'));
    }

    public function show(string $slug)
    {
        $series = Series::query()
            ->published()
            ->allowedRating()
            ->where('slug', $slug)
            ->firstOrFail();

        // Optimasi database dari kode lama: Mengganti whereHas (EXISTS) dengan JOIN (Direct Relation).
        // Select spesifik pada tabel asal untuk menghindari tabrakan nama kolom akibat JOIN.
        $wallpapers = Wallpaper::query()
            ->select('wallpapers.*')
            ->join('wallpaper_character', 'wallpapers.id', '=', 'wallpaper_character.wallpaper_id')
            ->join('character_series', 'wallpaper_character.character_id', '=', 'character_series.character_id')
            ->where('character_series.series_id', $series->id)
            ->published()
            ->allowedRating()
            ->distinct()
            ->latest('wallpapers.created_at') // Spesifikkan tabel untuk menghindari ambiguous column
            ->paginate(32);

        return view('series.show', compact('series', 'wallpapers'));
    }

    public function characters(string $slug)
    {
        $series = Series::query()
            ->published()
            ->allowedRating()
            ->where('slug', $slug)
            ->firstOrFail();

        $characters = $series->characters()
            ->published()
            ->allowedRating()
            ->paginate(32);

        return view('series.characters', compact('series', 'characters'));
    }
}