<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Wallpaper;
use App\Models\User;
use App\Models\Post;
use App\Models\Character;
use App\Models\Tag;
use App\Models\Series;
use App\Models\Artist;

class AdminController extends Controller
{
    /**
     * Menampilkan halaman utama dashboard admin beserta statistik lengkap.
     */
    public function index()
    {
        // 1. Master Statistics
        $totalWallpapers = Wallpaper::count();
        $totalUsers = User::count();
        $totalPosts = Post::count();
        $totalCharacters = Character::count();
        $totalTags = Tag::count();
        $totalSeries = Series::count();
        $totalArtists = Artist::count();

        // 2. Fetch Wallpaper Status
        $fetchWallpaperPending = DB::table('fetched_wallpapers')->where('status', 'pending')->count();
        $fetchWallpaperProcessing = DB::table('fetched_wallpapers')->where('status', 'processing')->count();
        $fetchWallpaperFailed = DB::table('fetched_wallpapers')->where('status', 'failed')->count();

        // 3. Task Fetch Status
        $taskFetchRunning = DB::table('fetch_tasks')->where('status', 'running')->count();
        $taskFetchCompleted = DB::table('fetch_tasks')->where('status', 'completed')->count();
        $taskFetchPending = DB::table('fetch_tasks')->where('status', 'pending')->count();

        // 4. Statistik User Perhari berdasarkan created_at dan updated_at (Untuk Grafik)
        $createdStats = User::select(DB::raw('DATE(created_at) as date'), DB::raw('count(*) as count'))
            ->whereNotNull('created_at')
            ->groupBy('date')
            ->get()
            ->pluck('count', 'date');

        $modifiedStats = User::select(DB::raw('DATE(updated_at) as date'), DB::raw('count(*) as count'))
            ->whereNotNull('updated_at')
            ->groupBy('date')
            ->get()
            ->pluck('count', 'date');

        // Mengambil 7 hari terakhir yang ada aktivitasnya, diurutkan secara kronologis (terlama ke terbaru untuk grafik)
        $allDates = $createdStats->keys()
            ->concat($modifiedStats->keys())
            ->unique()
            ->sortDesc()
            ->take(7)
            ->sort()
            ->values();

        $chartLabels = [];
        $chartDataCreated = [];
        $chartDataModified = [];

        foreach ($allDates as $date) {
            $chartLabels[] = \Carbon\Carbon::parse($date)->format('d M Y');
            $chartDataCreated[] = $createdStats->get($date, 0);
            $chartDataModified[] = $modifiedStats->get($date, 0);
        }

        // Mengirimkan seluruh variabel statistik ke file view dashboard admin
        return view('admin.dashboard.index', compact(
            'totalWallpapers',
            'totalUsers',
            'totalPosts',
            'totalCharacters',
            'totalTags',
            'totalSeries',
            'totalArtists',
            'fetchWallpaperPending',
            'fetchWallpaperProcessing',
            'fetchWallpaperFailed',
            'taskFetchRunning',
            'taskFetchCompleted',
            'taskFetchPending',
            'chartLabels',
            'chartDataCreated',
            'chartDataModified'
        ));
    }

    /**
     * Menampilkan halaman pengaturan admin.
     */
    public function settings()
    {
        // Mengambil data setting pertama
        $settings = DB::table('settings')->first();

        return view('admin.dashboard.settings', compact('settings'));
    }

    /**
     * Memproses update pengaturan aplikasi.
     */
    public function updateSettings(Request $request)
    {
        // Validasi input dari form
        $validated = $request->validate([
            'package_name' => 'required|string|max:255',
            'app_version' => 'required|string|max:255',
            'build_version' => 'required|integer',
            'url_playstore' => 'nullable|url',
            'banner_provider' => 'required|string|max:50',
            'open_app_provider' => 'required|string|max:50',
            'transition_mode' => 'required|string|max:50',
            'ad_interval' => 'required|integer',
            'admob_app_id' => 'nullable|string|max:255',
            'admob_banner_id' => 'nullable|string|max:255',
            'admob_interstitial_id' => 'nullable|string|max:255',
            'admob_rewarded_id' => 'nullable|string|max:255',
            'admob_rewarded_interstitial_id' => 'nullable|string|max:255',
            'admob_open_app_id' => 'nullable|string|max:255',
            'applovin_sdk_key' => 'nullable|string|max:255',
            'applovin_banner_id' => 'nullable|string|max:255',
            'applovin_interstitial_id' => 'nullable|string|max:255',
            'applovin_rewarded_id' => 'nullable|string|max:255',
            'applovin_open_app_id' => 'nullable|string|max:255',
        ]);

        $settings = DB::table('settings')->first();

        if ($settings) {
            // Jika data setting sudah ada, lakukan update
            DB::table('settings')->where('id', $settings->id)->update(array_merge($validated, [
                'updated_at' => now(),
            ]));
        } else {
            // Jika tabel kosong, masukkan data baru
            DB::table('settings')->insert(array_merge($validated, [
                'created_at' => now(),
                'updated_at' => now(),
            ]));
        }

        return redirect()->route('admin.settings')->with('success', 'Application settings updated successfully.');
    }
}