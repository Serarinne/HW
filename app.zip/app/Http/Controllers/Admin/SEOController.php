<?php

namespace App\Http\Controllers\Admin;

use App\Models\Wallpaper;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SEOController extends Controller
{
    public function generateWallpaperPrompt(int $id)
    {
        $wallpaper = Wallpaper::with(['characters', 'artists', 'tags'])->findOrFail($id);

        // Menggabungkan array nama menjadi string yang dipisahkan koma
        $charaNames = $wallpaper->characters->pluck('name')->implode(', ');
        $artistNames = $wallpaper->artists->pluck('name')->implode(', ');
        $tagNames = $wallpaper->tags->pluck('name')->implode(', ');

        // Menyusun prompt cerdas untuk ChatGPT/Claude/Gemini
        $prompt = "Kamu adalah ahli SEO. Tolong buatkan metadata SEO yang menarik dalam bahasa Inggris/Indonesia untuk sebuah wallpaper anime. Berikut adalah data gambarnya:\n\n";
        $prompt .= "- Karakter: " . ($charaNames ?: 'Tidak spesifik') . "\n";
        $prompt .= "- Seniman/Artist: " . ($artistNames ?: 'Tidak diketahui') . "\n";
        $prompt .= "- Tema/Tags: " . ($tagNames ?: 'Anime aesthetic, HD wallpaper') . "\n";
        $prompt .= "- Resolusi Gambar: {$wallpaper->width}x{$wallpaper->height}\n\n";
        $prompt .= "Tolong berikan balasan TANPA basa-basi dalam format murni seperti ini:\n\n";
        $prompt .= "SEO TITLE: [Buat judul yang memancing klik, maks 60 karakter]\n";
        $prompt .= "IMAGE ALT: [Deskripsi literal gambar untuk tunanetra dan mesin pencari]\n";
        $prompt .= "META DESCRIPTION: [Deskripsi naratif yang memancing klik, maks 150 karakter]\n";
        $prompt .= "KEYWORDS: [kata kunci 1, kata kunci 2, kata kunci 3...]";

        return response()->json([
            'status' => 'success',
            'prompt' => $prompt
        ]);
    }
}