<?php

namespace App\Http\Controllers;

use App\Models\Artist;
use Illuminate\Http\Request;

class ArtistController extends Controller
{
    public function index(Request $request)
    {
        $query = trim((string) $request->input('q', ''));

        $artists = Artist::query()
            // Menggunakan scopeSearch dari Model (Lebih aman untuk kata pendek)
            ->when($query !== '', function ($q) use ($query) {
                $q->search($query);
            })
            // Menggunakan scopeIndexList untuk hemat RAM dan mengambil jumlah wallpaper via JOIN
            ->indexList()
            // ->published() // Buka komentar jika diperlukan
            ->paginate(32)
            ->appends(['q' => $query]);

        return view('artists.index', compact('artists', 'query'));
    }

    public function show(string $slug)
    {
        // Tetap menggunakan seleksi sederhana karena ini adalah halaman detail (satu data)
        // Memuat relasi dataCount agar tidak terjadi N+1 jika view memanggil atribut wallpapers_count
        $artist = Artist::query()
            ->with(['dataCount', 'links', 'user']) 
            // ->published() // Buka komentar jika diperlukan
            ->where('slug', $slug)
            ->firstOrFail();

        $wallpapers = $artist->wallpapers()
            ->published()
            ->allowedRating()
            ->latest()
            ->paginate(32);

        return view('artists.show', compact('artist', 'wallpapers'));
    }
}