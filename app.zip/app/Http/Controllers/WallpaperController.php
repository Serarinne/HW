<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\Wallpaper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Auth;

class WallpaperController extends Controller
{
    public function index()
    {
        // Menggunakan simplePaginate untuk menghilangkan query COUNT(*) yang berat
        $wallpapers = Wallpaper::query()
            ->select('id', 'slug', 'thumbnail', 'height', 'width', 'views_count')
            ->published()
            ->allowedRating()
            ->latest()
            ->paginate(32);

        // Caching selama 6 jam (21600 detik) untuk popular wallpapers
        $popularWallpapers = Wallpaper::query()
                ->select('id', 'slug', 'thumbnail')
                ->published()
                ->allowedRating()
                ->where('created_at', '>=', now()->subDays(7))
                ->withCount('favorites')
                ->orderByDesc('favorites_count')
                ->limit(6)
                ->get();

        // Caching selama 12 jam untuk trending tags
        $trendingTags = Tag::query()
                ->select('id', 'slug', 'image', 'name')
                ->published()
                ->allowedRating()
                ->trending(8)
                ->get();

        return view('wallpapers.index', compact('wallpapers', 'popularWallpapers', 'trendingTags'));
    }

    public function search(Request $request)
    {
        $query = trim((string) $request->input('q', ''));

        if ($query === '') {
            return view('wallpapers.search', [
                'query' => $query,
                'wallpapers' => collect(),
            ]);
        }

        $wallpapers = Wallpaper::query()
            ->published()
            ->allowedRating()
            ->when($query !== '', function ($q) use ($query) {
                $q->search($query);
            })
            ->latest()
            ->paginate(32) // Menggunakan simplePaginate
            ->appends(['q' => $query]);

        return view('wallpapers.search', compact('wallpapers', 'query'));
    }

    public function redirectToSlug($id)
    {
        // Cache pencarian slug berdasarkan ID untuk mengurangi hit ke DB
        $wallpaper = Cache::remember('wallpaper_slug_by_id_' . $id, now()->addDays(30), function () use ($id) {
            return Wallpaper::query()
                ->select(['id', 'slug'])
                ->findOrFail($id);
        });

        return redirect()->route('wallpapers.show', ['slug' => $wallpaper->slug]);
    }

    public function show(string $slug)
    {
        $wallpaper = Wallpaper::query()
                ->published()
                // ->allowedRating()
                ->where('slug', $slug)
                ->with([
                    'artists' => function ($query) {
                        $query->select(['artists.id', 'artists.name', 'artists.slug', 'artists.image']);
                    },
                    'tags' => function ($query) {
                        $query->published()->allowedRating()
                            ->select(['tags.id', 'tags.name', 'tags.slug', 'tags.image']);
                    },
                    'characters' => function ($query) {
                        $query->published()->allowedRating()
                            ->whereHas('series')
                            ->select(['characters.id', 'characters.name', 'characters.slug', 'characters.image']);
                    },
                ])
                ->firstOrFail();

        if (!$wallpaper->isVisibleToUser()) {
            if (Auth::guest()) {
                return redirect()->route('login')
                    ->with('error', 'Please log in to view this content.');
            }

            // Jika user sudah login tapi rating tidak sesuai
            return redirect()->route('settings.edit')
                ->with('warning', 'This content is hidden by your current rating preferences. Please update your settings to view it.');
        }

        $this->incrementViews($wallpaper);

        // return compact('wallpaper');
        return view('wallpapers.show', compact('wallpaper'));
    }

    private function incrementViews(Wallpaper $wallpaper)
    {
        $ip = request()->ip();
        $key = 'view_wallpaper_' . $wallpaper->id . '_' . $ip;
        
        if (Cache::has($key)) {
            return;
        }
        
        $originalUpdatedAt = $wallpaper->updated_at;
        
        \DB::table('wallpapers')
            ->where('id', $wallpaper->id)
            ->update([
                'views_count' => $wallpaper->views_count + 1,
                'updated_at' => $originalUpdatedAt
            ]);
        
        Cache::put($key, true, now()->addDays(1));
    }
}