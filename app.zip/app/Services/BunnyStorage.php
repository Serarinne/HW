<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class BunnyStorage
{
    protected $storageZone;
    protected $apiKey;
    protected $region; // sg, ny, la, etc (kosong = default/de)

    public function __construct($storageZone = null, $apiKey = null, $region = null)
    {
        $this->storageZone = $storageZone;
        $this->apiKey = $apiKey;
        $this->region = $region;
    }

    /**
     * Helper untuk mendapatkan Base URL sesuai Region
     */
    private function getBaseUrl()
    {
        // Jika region ada (misal 'sg' atau 'ny'), formatnya: https://sg.storage.bunnycdn.com
        // Jika region kosong/null, default: https://storage.bunnycdn.com
        if ($this->region) {
            return "https://{$this->region}.storage.bunnycdn.com";
        }
        return "https://storage.bunnycdn.com";
    }

    /**
     * Upload File (Support Binary Image/Video)
     * Menggunakan withBody() agar TIDAK terkena json_encode error.
     */
    public function upload($path, $content)
    {
        $url = "{$this->getBaseUrl()}/{$this->storageZone}/{$path}";

        // PERBAIKAN UTAMA DISINI:
        // Gunakan ->withBody($content, 'application/octet-stream')
        // Jangan masukkan $content ke dalam array parameter put()
        
        $response = Http::withHeaders([
            'AccessKey' => $this->apiKey,
            'Content-Type' => 'application/octet-stream', // Paksa tipe biner
        ])
        ->withBody($content, 'application/octet-stream')
        ->put($url);

        if ($response->failed()) {
            throw new \Exception("BunnyCDN Upload Failed: " . $response->body());
        }

        return true;
    }

    /**
     * Delete File
     */
    public function delete($path)
    {
        $url = "{$this->getBaseUrl()}/{$this->storageZone}/{$path}";

        $response = Http::withHeaders([
            'AccessKey' => $this->apiKey,
        ])->delete($url);

        // 404 dianggap sukses (file sudah tidak ada)
        if ($response->failed() && $response->status() != 404) {
            Log::error("BunnyCDN Delete Failed: " . $response->body());
            return false;
        }

        return true;
    }
    
    /**
     * Cek apakah file ada (Opsional helper)
     */
    public function exists($path)
    {
        $url = "{$this->getBaseUrl()}/{$this->storageZone}/{$path}";
        
        $response = Http::withHeaders([
            'AccessKey' => $this->apiKey,
        ])->get($url); // Menggunakan GET untuk cek, atau HEAD jika didukung

        return $response->successful();
    }
}